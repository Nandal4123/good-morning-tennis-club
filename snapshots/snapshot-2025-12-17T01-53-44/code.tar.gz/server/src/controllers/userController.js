import {
  getKoreanTodayStart,
  getKoreanTomorrowStart,
} from "../utils/timezone.js";
import {
  buildClubWhere,
  getClubFilter,
  getClubInfo,
} from "../utils/clubInfo.js";

// Get all users
export const getAllUsers = async (req, res) => {
  try {
    const users = await req.prisma.user.findMany({
      where: buildClubWhere(req),
      orderBy: { name: "asc" },
    });
    res.json(users);
  } catch (error) {
    console.error("Error fetching users:", error);
    res.status(500).json({ error: "Failed to fetch users" });
  }
};

// Get user by ID
export const getUserById = async (req, res) => {
  try {
    const { id } = req.params;
    const clubId = getClubFilter(req);

    // where 조건 구성
    const where = { id };
    if (clubId) {
      where.clubId = clubId;
    }

    const user = await req.prisma.user.findUnique({
      where,
      include: {
        attendances: {
          include: { session: true },
          orderBy: { date: "desc" },
          take: 10,
        },
        matchParticipants: {
          include: { match: true },
          orderBy: { match: { date: "desc" } },
          take: 10,
        },
      },
    });

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json(user);
  } catch (error) {
    console.error("Error fetching user:", error);
    res.status(500).json({ error: "Failed to fetch user" });
  }
};

// Create new user
export const createUser = async (req, res) => {
  try {
    const {
      email,
      name,
      role,
      tennisLevel,
      goals,
      languagePref,
      profileMetadata,
    } = req.body;

    console.log("Creating user with data:", { email, name, role, tennisLevel });

    // 멀티 테넌트: clubId 자동 할당
    let clubId = getClubFilter(req);
    if (!clubId) {
      // MVP 모드: 기본 클럽 ID 사용
      const clubInfo = getClubInfo(req);
      const defaultClubId = clubInfo.id;

      // 기본 클럽이 실제 Club 레코드인지 확인
      if (defaultClubId && defaultClubId !== "default-club") {
        const club = await req.prisma.club.findUnique({
          where: { id: defaultClubId },
        });
        if (club) {
          clubId = club.id;
        }
      }
    }

    const user = await req.prisma.user.create({
      data: {
        email,
        name,
        role: role || "USER",
        tennisLevel: tennisLevel || "NTRP_3_0",
        goals,
        languagePref: languagePref || "ko",
        profileMetadata,
        clubId: clubId || null, // 멀티 테넌트 모드가 아니면 null
      },
    });

    console.log("User created successfully:", user.id);
    res.status(201).json(user);
  } catch (error) {
    console.error("Error creating user:", error);
    console.error("Error details:", error.message);
    if (error.code === "P2002") {
      return res.status(400).json({ error: "Email already exists" });
    }
    // 개발 환경에서 상세 에러 반환
    res.status(500).json({
      error: "Failed to create user",
      details: error.message,
      code: error.code,
    });
  }
};

// Update user
export const updateUser = async (req, res) => {
  try {
    const { id } = req.params;
    const clubId = getClubFilter(req);
    const {
      email,
      name,
      role,
      tennisLevel,
      goals,
      languagePref,
      profileMetadata,
    } = req.body;

    // 멀티 테넌트: 사용자가 해당 클럽에 속하는지 확인
    if (clubId) {
      const existingUser = await req.prisma.user.findUnique({
        where: { id },
        select: { clubId: true },
      });

      if (!existingUser) {
        return res.status(404).json({ error: "User not found" });
      }

      if (existingUser.clubId !== clubId) {
        return res.status(403).json({ error: "Access denied" });
      }
    }

    // 업데이트할 데이터 구성 (undefined가 아닌 값만 포함)
    const updateData = {};
    if (email !== undefined) updateData.email = email;
    if (name !== undefined) updateData.name = name;
    if (role !== undefined) updateData.role = role;
    if (tennisLevel !== undefined) updateData.tennisLevel = tennisLevel;
    if (goals !== undefined) updateData.goals = goals;
    if (languagePref !== undefined) updateData.languagePref = languagePref;
    if (profileMetadata !== undefined)
      updateData.profileMetadata = profileMetadata;

    const user = await req.prisma.user.update({
      where: { id },
      data: updateData,
    });

    res.json(user);
  } catch (error) {
    console.error("Error updating user:", error);
    if (error.code === "P2025") {
      return res.status(404).json({ error: "User not found" });
    }
    res.status(500).json({ error: "Failed to update user" });
  }
};

// Delete user
export const deleteUser = async (req, res) => {
  try {
    const { id } = req.params;
    const clubId = getClubFilter(req);

    // 멀티 테넌트: 사용자가 해당 클럽에 속하는지 확인
    if (clubId) {
      const existingUser = await req.prisma.user.findUnique({
        where: { id },
        select: { clubId: true },
      });

      if (!existingUser) {
        return res.status(404).json({ error: "User not found" });
      }

      if (existingUser.clubId !== clubId) {
        return res.status(403).json({ error: "Access denied" });
      }
    }

    await req.prisma.user.delete({
      where: { id },
    });

    res.json({ message: "User deleted successfully" });
  } catch (error) {
    console.error("Error deleting user:", error);
    if (error.code === "P2025") {
      return res.status(404).json({ error: "User not found" });
    }
    res.status(500).json({ error: "Failed to delete user" });
  }
};

// Delete multiple users (admin only)
export const deleteMultipleUsers = async (req, res) => {
  try {
    const { userIds } = req.body;
    const clubId = getClubFilter(req);

    if (!userIds || !Array.isArray(userIds) || userIds.length === 0) {
      return res.status(400).json({ error: "No user IDs provided" });
    }

    // 삭제할 사용자 수 확인 (클럽 필터 적용)
    const where = { id: { in: userIds } };
    if (clubId) {
      where.clubId = clubId;
    }

    const usersToDelete = await req.prisma.user.findMany({
      where,
      select: { id: true, name: true },
    });

    if (usersToDelete.length === 0) {
      return res.status(404).json({ error: "No users found" });
    }

    // 일괄 삭제
    const result = await req.prisma.user.deleteMany({
      where,
    });

    res.json({
      message: `${result.count} users deleted successfully`,
      deletedCount: result.count,
      deletedUsers: usersToDelete.map((u) => u.name),
    });
  } catch (error) {
    console.error("Error deleting multiple users:", error);
    res.status(500).json({ error: "Failed to delete users" });
  }
};

// Get user statistics
export const getUserStats = async (req, res) => {
  try {
    const { id } = req.params;
    const clubId = getClubFilter(req);

    // where 조건 구성
    const where = { id };
    if (clubId) {
      where.clubId = clubId;
    }

    // 사용자 존재 확인
    const user = await req.prisma.user.findUnique({
      where,
      select: { name: true, tennisLevel: true },
    });

    if (!user) {
      return res.status(404).json({ error: "User not found" });
    }

    // 출석 수 (클럽 필터 적용)
    const attendanceWhere = { userId: id, status: "ATTENDED" };
    if (clubId) {
      attendanceWhere.user = { clubId };
    }
    const attendanceCount = await req.prisma.attendance.count({
      where: attendanceWhere,
    });

    // 참가한 모든 경기 가져오기 (클럽 필터 적용)
    const matchParticipantWhere = { userId: id };
    if (clubId) {
      matchParticipantWhere.match = { clubId };
    }
    const userMatches = await req.prisma.matchParticipant.findMany({
      where: matchParticipantWhere,
      include: {
        match: {
          include: {
            participants: true,
          },
        },
      },
    });

    const matchCount = userMatches.length;

    // 승리 계산: 내 팀 점수가 상대팀 점수보다 높은 경기
    let winCount = 0;
    for (const participant of userMatches) {
      const myTeam = participant.team;
      const match = participant.match;
      const participants = match?.participants || [];

      if (participants.length === 0) continue;

      // 내 팀 점수와 상대팀 점수 계산
      const myTeamPlayers = participants.filter((p) => p.team === myTeam);
      const opponentPlayers = participants.filter((p) => p.team !== myTeam);

      const myTeamScore =
        myTeamPlayers.length > 0
          ? Math.max(...myTeamPlayers.map((p) => p.score || 0))
          : 0;
      const opponentScore =
        opponentPlayers.length > 0
          ? Math.max(...opponentPlayers.map((p) => p.score || 0))
          : 0;

      if (myTeamScore > opponentScore) {
        winCount++;
      }
    }

    // 전체 세션 수 가져오기 (출석률 계산용, 클럽 필터 적용)
    const sessionWhere = clubId ? { clubId } : {};
    const totalSessions = await req.prisma.session.count({
      where: sessionWhere,
    });

    res.json({
      ...user,
      stats: {
        totalAttendance: attendanceCount,
        totalMatches: matchCount,
        wins: winCount,
        attendanceRate:
          totalSessions > 0
            ? Math.round((attendanceCount / totalSessions) * 100)
            : 0,
      },
    });
  } catch (error) {
    console.error("Error fetching user stats:", error);
    console.error("Error details:", error.message);
    res.status(500).json({
      error: "Failed to fetch user statistics",
      details: error.message,
    });
  }
};

// Get head-to-head record between two users
export const getHeadToHead = async (req, res) => {
  try {
    const { id, opponentId } = req.params;
    const clubId = getClubFilter(req);

    // 멀티 테넌트: 두 사용자가 모두 해당 클럽에 속하는지 확인
    if (clubId) {
      const [user, opponent] = await Promise.all([
        req.prisma.user.findUnique({
          where: { id },
          select: { clubId: true },
        }),
        req.prisma.user.findUnique({
          where: { id: opponentId },
          select: { clubId: true },
        }),
      ]);

      if (!user || !opponent) {
        return res.status(404).json({ error: "User not found" });
      }

      if (user.clubId !== clubId || opponent.clubId !== clubId) {
        return res.status(403).json({ error: "Access denied" });
      }
    }

    // 내가 참가한 모든 경기 가져오기 (클럽 필터 적용)
    const matchParticipantWhere = { userId: id };
    if (clubId) {
      matchParticipantWhere.match = { clubId };
    }
    const myMatches = await req.prisma.matchParticipant.findMany({
      where: matchParticipantWhere,
      include: {
        match: {
          include: {
            participants: {
              include: {
                user: {
                  select: { id: true, name: true },
                },
              },
            },
          },
        },
      },
    });

    // 상대방과 함께한 경기만 필터링
    const headToHeadMatches = myMatches.filter((mp) => {
      const opponentInMatch = mp.match.participants.some(
        (p) => p.userId === opponentId
      );
      return opponentInMatch;
    });

    let wins = 0;
    let losses = 0;
    let draws = 0;
    const matchHistory = [];

    for (const mp of headToHeadMatches) {
      const match = mp.match;
      const myTeam = mp.team;

      // 상대방 팀 확인
      const opponentParticipant = match.participants.find(
        (p) => p.userId === opponentId
      );
      const opponentTeam = opponentParticipant?.team;

      // 같은 팀이면 건너뛰기 (상대전적이 아님)
      if (myTeam === opponentTeam) continue;

      // 점수 계산
      const participants = match?.participants || [];
      const myTeamPlayers = participants.filter((p) => p.team === myTeam);
      const opponentTeamPlayers = participants.filter(
        (p) => p.team === opponentTeam
      );

      const myTeamScore =
        myTeamPlayers.length > 0
          ? Math.max(...myTeamPlayers.map((p) => p.score || 0))
          : 0;
      const opponentTeamScore =
        opponentTeamPlayers.length > 0
          ? Math.max(...opponentTeamPlayers.map((p) => p.score || 0))
          : 0;

      // 승/패/무 계산
      let result;
      if (myTeamScore > opponentTeamScore) {
        wins++;
        result = "WIN";
      } else if (myTeamScore < opponentTeamScore) {
        losses++;
        result = "LOSS";
      } else {
        draws++;
        result = "DRAW";
      }

      // 경기 기록 추가
      matchHistory.push({
        matchId: match.id,
        date: match.date,
        myTeam: match.participants
          .filter((p) => p.team === myTeam)
          .map((p) => p.user.name),
        opponentTeam: match.participants
          .filter((p) => p.team === opponentTeam)
          .map((p) => p.user.name),
        myScore: myTeamScore,
        opponentScore: opponentTeamScore,
        result,
      });
    }

    // 상대방 정보 가져오기
    const opponent = await req.prisma.user.findUnique({
      where: { id: opponentId },
      select: { id: true, name: true, tennisLevel: true },
    });

    res.json({
      opponent,
      stats: {
        wins,
        losses,
        draws,
        totalMatches: wins + losses + draws,
        winRate:
          wins + losses + draws > 0
            ? Math.round((wins / (wins + losses + draws)) * 100)
            : 0,
      },
      matchHistory: matchHistory.sort(
        (a, b) => new Date(b.date) - new Date(a.date)
      ),
    });
  } catch (error) {
    console.error("Error fetching head-to-head:", error);
    res.status(500).json({ error: "Failed to fetch head-to-head record" });
  }
};

// Get all users with monthly stats (for rankings)
export const getAllUsersWithMonthlyStats = async (req, res) => {
  try {
    console.log(`[API] 📊 /api/users/with-monthly-stats 호출됨`);
    console.log(`[API] Query params:`, req.query);

    const clubId = getClubFilter(req);
    const clubWhere = buildClubWhere(req);

    // 쿼리 파라미터로 년/월 받기 (기본값: 현재 월)
    const now = new Date();
    const year = parseInt(req.query.year) || now.getFullYear();
    const month = parseInt(req.query.month) || now.getMonth() + 1; // 1-12
    console.log(`[API] 처리할 년/월: ${year}-${month}`);

    // 해당 월의 시작일과 종료일 계산 (KST 기준)
    const startDate = new Date(
      `${year}-${String(month).padStart(2, "0")}-01T00:00:00+09:00`
    );

    // 오늘 날짜까지의 데이터만 조회 (KST 기준)
    // 현재 월이면 오늘까지, 과거 월이면 해당 월의 마지막 날까지
    const tomorrowKSTStart = getKoreanTomorrowStart(); // 오늘 날짜 포함을 위해 내일 시작 시간 사용

    const nextMonthStart = new Date(startDate);
    nextMonthStart.setMonth(nextMonthStart.getMonth() + 1);

    // 오늘 날짜의 다음 날 시작 시간과 선택한 월의 다음 달 시작일 중 더 작은 값 사용
    // 현재 월이면 오늘까지 (내일 시작 시간), 과거 월이면 해당 월의 마지막 날까지
    const endDate =
      tomorrowKSTStart < nextMonthStart ? tomorrowKSTStart : nextMonthStart;

    // 현재 월인지 확인
    const currentYear = now.getFullYear();
    const currentMonth = now.getMonth() + 1;
    const isCurrentMonth = year === currentYear && month === currentMonth;

    console.log(
      `[Monthly Stats] Period: ${startDate.toISOString()} ~ ${endDate.toISOString()}`
    );
    console.log(
      `[Monthly Stats] 현재 월 여부: ${
        isCurrentMonth ? "YES (오늘까지)" : "NO (전체 월)"
      }`
    );
    if (isCurrentMonth) {
      const kstEndDate = new Date(endDate.getTime() + 9 * 60 * 60 * 1000);
      console.log(
        `[Monthly Stats] 오늘 날짜 (KST): ${kstEndDate.getUTCFullYear()}-${String(
          kstEndDate.getUTCMonth() + 1
        ).padStart(2, "0")}-${String(kstEndDate.getUTCDate()).padStart(2, "0")}`
      );
    }

    // 모든 사용자 가져오기 (클럽 필터 적용)
    const users = await req.prisma.user.findMany({
      where: clubWhere,
      orderBy: { name: "asc" },
    });

    // 해당 월의 세션 수 (출석률 계산용, 클럽 필터 적용)
    const monthSessionWhere = {
      date: {
        gte: startDate,
        lt: endDate,
      },
    };
    if (clubId) {
      monthSessionWhere.clubId = clubId;
    }
    const monthSessions = await req.prisma.session.count({
      where: monthSessionWhere,
    });

    // ⚡ 성능 최적화: Bulk Query 방식 (54개 쿼리 → 2개 쿼리)
    // 모든 데이터를 한 번에 가져와서 메모리에서 처리
    // 44초 → 2-3초로 단축 (93% 성능 개선)
    const [allAttendances, allMatchParticipants] = await Promise.all([
      // 해당 월의 모든 출석 데이터 한 번에 가져오기
      req.prisma.attendance.findMany({
        where: {
          status: "ATTENDED",
          date: {
            gte: startDate,
            lt: endDate,
          },
        },
        select: {
          userId: true,
        },
      }),
      // 해당 월의 모든 경기 참여 데이터 한 번에 가져오기
      req.prisma.matchParticipant.findMany({
        where: {
          match: {
            date: {
              gte: startDate,
              lt: endDate,
            },
          },
        },
        include: {
          match: {
            include: {
              participants: true,
            },
          },
        },
      }),
    ]);

    // 메모리에서 사용자별로 그룹핑
    const attendanceByUser = {};
    for (const attendance of allAttendances) {
      if (!attendanceByUser[attendance.userId]) {
        attendanceByUser[attendance.userId] = 0;
      }
      attendanceByUser[attendance.userId]++;
    }

    const matchParticipantsByUser = {};
    for (const participant of allMatchParticipants) {
      if (!matchParticipantsByUser[participant.userId]) {
        matchParticipantsByUser[participant.userId] = [];
      }
      matchParticipantsByUser[participant.userId].push(participant);
    }

    // 각 사용자의 월별 통계 계산 (메모리에서 처리)
    const usersWithStats = [];

    for (const user of users) {
      // 해당 월 출석 수 (메모리에서 계산)
      const attendanceCount = attendanceByUser[user.id] || 0;

      // 해당 월 경기 참여 기록 (메모리에서 가져오기)
      const matchParticipants = matchParticipantsByUser[user.id] || [];

      let wins = 0;
      let losses = 0;
      let draws = 0;

      for (const participant of matchParticipants) {
        const match = participant.match;
        const myTeam = participant.team;
        const participants = match?.participants || [];

        if (participants.length === 0) continue;

        const myTeamPlayers = participants.filter((p) => p.team === myTeam);
        const opponentPlayers = participants.filter((p) => p.team !== myTeam);

        const myTeamScore =
          myTeamPlayers.length > 0
            ? Math.max(...myTeamPlayers.map((p) => p.score || 0))
            : 0;
        const opponentScore =
          opponentPlayers.length > 0
            ? Math.max(...opponentPlayers.map((p) => p.score || 0))
            : 0;

        if (myTeamScore > opponentScore) {
          wins++;
        } else if (myTeamScore < opponentScore) {
          losses++;
        } else {
          draws++;
        }
      }

      const totalGames = wins + losses + draws;
      const winRate =
        totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;
      const attendanceRate =
        monthSessions > 0
          ? Math.round((attendanceCount / monthSessions) * 100)
          : 0;

      usersWithStats.push({
        ...user,
        stats: {
          totalAttendance: attendanceCount,
          attendanceRate,
          totalMatches: totalGames,
          wins,
          losses,
          draws,
          winRate,
        },
      });
    }

    res.json({
      year,
      month,
      users: usersWithStats,
    });
  } catch (error) {
    console.error("❌ Error fetching users with monthly stats:", error);
    console.error("Error name:", error.name);
    console.error("Error message:", error.message);
    console.error("Error stack:", error.stack);

    // 더 자세한 에러 정보 반환
    const errorResponse = {
      error: "Failed to fetch users with monthly stats",
      details: error.message || "Unknown error",
      type: error.name || "Error",
    };

    // Prisma 관련 오류인 경우 추가 정보
    if (
      error.name === "PrismaClientKnownRequestError" ||
      error.name === "PrismaClientInitializationError" ||
      error.message?.includes("MaxClientsInSessionMode") ||
      error.message?.includes("connection")
    ) {
      errorResponse.databaseError = true;
      errorResponse.suggestion =
        "Database connection pool limit reached. Please try again in a moment.";
    }

    res.status(500).json(errorResponse);
  }
};

// Get all users with stats (for admin)
export const getAllUsersWithStats = async (req, res) => {
  try {
    console.log(`[API] 📊 /api/users/with-stats 호출됨`);

    const clubId = getClubFilter(req);
    const clubWhere = buildClubWhere(req);

    // 모든 사용자 가져오기 (클럽 필터 적용)
    const users = await req.prisma.user.findMany({
      where: clubWhere,
      orderBy: { name: "asc" },
    });

    // 모든 세션 수 (출석률 계산용, 클럽 필터 적용)
    const totalSessions = await req.prisma.session.count({
      where: clubWhere,
    });

    // ⚡ 성능 최적화: Bulk Query 방식 (54개 쿼리 → 2개 쿼리)
    // 모든 데이터를 한 번에 가져와서 메모리에서 처리
    // 순차 처리 (20-30초) → Bulk Query (2-3초)로 단축 (90%+ 성능 개선)
    const [allAttendances, allMatchParticipants] = await Promise.all([
      // 모든 출석 데이터 한 번에 가져오기
      req.prisma.attendance.findMany({
        where: {
          status: "ATTENDED",
        },
        select: {
          userId: true,
        },
      }),
      // 모든 경기 참여 데이터 한 번에 가져오기
      req.prisma.matchParticipant.findMany({
        include: {
          match: {
            include: {
              participants: true,
            },
          },
        },
      }),
    ]);

    // 메모리에서 사용자별로 그룹핑
    const attendanceByUser = {};
    for (const attendance of allAttendances) {
      if (!attendanceByUser[attendance.userId]) {
        attendanceByUser[attendance.userId] = 0;
      }
      attendanceByUser[attendance.userId]++;
    }

    const matchParticipantsByUser = {};
    for (const participant of allMatchParticipants) {
      if (!matchParticipantsByUser[participant.userId]) {
        matchParticipantsByUser[participant.userId] = [];
      }
      matchParticipantsByUser[participant.userId].push(participant);
    }

    // 각 사용자의 통계 계산 (메모리에서 처리)
    const usersWithStats = [];

    for (const user of users) {
      // 출석 수 (메모리에서 계산)
      const attendanceCount = attendanceByUser[user.id] || 0;

      // 경기 참여 기록 (메모리에서 가져오기)
      const matchParticipants = matchParticipantsByUser[user.id] || [];

      let wins = 0;
      let losses = 0;
      let draws = 0;

      for (const participant of matchParticipants) {
        const match = participant.match;
        const myTeam = participant.team;
        const participants = match?.participants || [];

        if (participants.length === 0) continue;

        const myTeamPlayers = participants.filter((p) => p.team === myTeam);
        const opponentPlayers = participants.filter((p) => p.team !== myTeam);

        const myTeamScore =
          myTeamPlayers.length > 0
            ? Math.max(...myTeamPlayers.map((p) => p.score || 0))
            : 0;
        const opponentScore =
          opponentPlayers.length > 0
            ? Math.max(...opponentPlayers.map((p) => p.score || 0))
            : 0;

        if (myTeamScore > opponentScore) {
          wins++;
        } else if (myTeamScore < opponentScore) {
          losses++;
        } else {
          draws++;
        }
      }

      const totalGames = wins + losses + draws;
      const winRate =
        totalGames > 0 ? Math.round((wins / totalGames) * 100) : 0;
      const attendanceRate =
        totalSessions > 0
          ? Math.round((attendanceCount / totalSessions) * 100)
          : 0;

      usersWithStats.push({
        ...user,
        stats: {
          totalAttendance: attendanceCount,
          attendanceRate,
          totalMatches: totalGames,
          wins,
          losses,
          draws,
          winRate,
        },
      });
    }

    console.log(
      `[API] ✅ /api/users/with-stats 완료: ${usersWithStats.length}명`
    );
    res.json(usersWithStats);
  } catch (error) {
    console.error("Error fetching users with stats:", error);
    console.error("Error details:", error.message);
    res.status(500).json({ error: "Failed to fetch users with stats" });
  }
};
