import { createPrismaClient } from "./create-prisma-client.js";
import dotenv from "dotenv";
import fs from "fs";
import path from "path";

dotenv.config();

function parseArgs(argv) {
  const args = { file: null, yes: false };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === "--file") args.file = argv[i + 1];
    if (a === "--yes") args.yes = true;
  }
  return args;
}

function requireFile(filePath) {
  if (!filePath) throw new Error("Missing --file <path-to-db.json>");
  const p = path.isAbsolute(filePath)
    ? filePath
    : path.join(process.cwd(), filePath);
  if (!fs.existsSync(p)) throw new Error(`Backup file not found: ${p}`);
  return p;
}

async function main() {
  const { file, yes } = parseArgs(process.argv.slice(2));
  const backupPath = requireFile(file);

  if (!yes) {
    console.error("❌ 중단: --yes 옵션이 필요합니다.");
    console.error("이 스크립트는 DB 데이터를 삭제한 뒤 스냅샷으로 복구합니다.");
    console.error(
      `실행 예시: pnpm run db:restore-snapshot -- --file \"${backupPath}\" --yes`
    );
    process.exit(1);
  }

  const raw = fs.readFileSync(backupPath, "utf-8");
  const payload = JSON.parse(raw);

  if (!payload || payload.type !== "snapshot" || !payload.data) {
    throw new Error("Invalid snapshot format (expected type=snapshot)");
  }

  const prisma = createPrismaClient();

  try {
    console.log("🧯 Snapshot 복구 시작");
    console.log("📄 Snapshot file:", backupPath);

    // 1) wipe existing data (order matters)
    console.log("\n1) 기존 데이터 삭제 중...");
    await prisma.feedback.deleteMany();
    await prisma.attendance.deleteMany();
    await prisma.matchParticipant.deleteMany();
    await prisma.match.deleteMany();
    await prisma.session.deleteMany();
    await prisma.user.deleteMany();
    await prisma.club.deleteMany();
    console.log("✅ 기존 데이터 삭제 완료");

    // 2) restore data (order matters)
    console.log("\n2) 스냅샷 데이터 복구 중...");
    const d = payload.data;

    if (Array.isArray(d.clubs) && d.clubs.length > 0) {
      await prisma.club.createMany({ data: d.clubs, skipDuplicates: false });
      console.log(`✅ clubs: ${d.clubs.length}`);
    } else {
      console.log("⚠️ clubs: 0 (스냅샷에 없음)");
    }

    if (Array.isArray(d.users) && d.users.length > 0) {
      await prisma.user.createMany({ data: d.users, skipDuplicates: false });
      console.log(`✅ users: ${d.users.length}`);
    } else {
      console.log("⚠️ users: 0");
    }

    if (Array.isArray(d.sessions) && d.sessions.length > 0) {
      await prisma.session.createMany({ data: d.sessions, skipDuplicates: false });
      console.log(`✅ sessions: ${d.sessions.length}`);
    } else {
      console.log("⚠️ sessions: 0");
    }

    if (Array.isArray(d.matches) && d.matches.length > 0) {
      await prisma.match.createMany({ data: d.matches, skipDuplicates: false });
      console.log(`✅ matches: ${d.matches.length}`);
    } else {
      console.log("⚠️ matches: 0");
    }

    if (Array.isArray(d.matchParticipants) && d.matchParticipants.length > 0) {
      await prisma.matchParticipant.createMany({
        data: d.matchParticipants,
        skipDuplicates: false,
      });
      console.log(`✅ matchParticipants: ${d.matchParticipants.length}`);
    } else {
      console.log("⚠️ matchParticipants: 0");
    }

    if (Array.isArray(d.attendances) && d.attendances.length > 0) {
      await prisma.attendance.createMany({
        data: d.attendances,
        skipDuplicates: false,
      });
      console.log(`✅ attendances: ${d.attendances.length}`);
    } else {
      console.log("⚠️ attendances: 0");
    }

    if (Array.isArray(d.feedbacks) && d.feedbacks.length > 0) {
      await prisma.feedback.createMany({
        data: d.feedbacks,
        skipDuplicates: false,
      });
      console.log(`✅ feedbacks: ${d.feedbacks.length}`);
    } else {
      console.log("⚠️ feedbacks: 0");
    }

    console.log("\n🎉 Snapshot 복구 완료");
  } finally {
    await prisma.$disconnect();
  }
}

main().catch((e) => {
  console.error("❌ 복구 실패:", e);
  process.exit(1);
});


